while True: 
    n = int(input("N 입력: ")) 
    for i in range(1, n + 1): 
        if i % 15 == 0: 
            print("3 과 5의 공배수") 
        elif i % 3 == 0: 
            print("3의 배수") 
        elif i % 5 == 0: 
            print("5의 배수") 
        else: 
            print(i) 
 
    again = input("계속하시겠습니까? (y/n): ") 
 
    if again == "n": 
        print("프로그램 종료") 
        break