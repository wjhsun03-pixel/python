numbers = [] 
while True: 
    num = int(input("숫자 입력: ")) 
    if num == 0: 
        break 
    numbers.append(num) 
positive = 0 
negative = 0 
even = 0 
odd = 0 
total = 0 
for num in numbers: 
    if num > 0: 
        positive += 1 
    elif num < 0: 
        negative += 1 
    if num % 2 == 0: 
        even += 1 
    else: 
        odd += 1 
    total += num 
print() 
print(f"양수 개수: {positive}") 
print(f"음수 개수: {negative}") 
print(f"짝수 개수: {even}") 
print(f"홀수 개수: {odd}") 
print(f"총합: {total}")     